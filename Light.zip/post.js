Page({

  onTapJump1: function (event) {
    wx.request({
      url:
        'https://api.heclouds.com/devices/505478393/datapoints',
      header: {
        'content-type': 'application/json',
        "api-key": 'ZLbaMJIwRocSuDGR9BifAVzzD9c='
      },
      method: "post",
      data: {
        "datastreams":[{
          "id":"�ƵĿ���",
          "datapoints": [{
        
            "value":"1", 
            "required":false
        }]
        }]
      },
      success(res) {
        console.log(res)
       
      },
      fail(res) {
        console.log("����ʧ��")
        
      },
      complete() {
        
        
      }
    })
  },





  onTapJump2: function (event) {
    wx.request({
      url:
        'https://api.heclouds.com/devices/505478393/datapoints',
      header: {
        'content-type': 'application/json',
        "api-key": 'ZLbaMJIwRocSuDGR9BifAVzzD9c='
      },
      method: "post",
      data: {
        "datastreams": [{
          "id": "�ƵĿ���",
          "datapoints": [{

            "value": "0",
            "required": false
          }]
        }]
      },
      success(res) {
        console.log(res)

      },
      fail(res) {
        console.log("����ʧ��")

      },
      complete() {


      }
    })
  }

  })